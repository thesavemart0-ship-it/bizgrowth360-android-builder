=== WPMobile.App – Android and iOS App Builder ===
Contributors: amauric
Tags: mobile app, android app, ios app, app builder, push notifications
Requires at least: 3.7.0
Tested up to: 7.1
Requires PHP: 5.6
Stable tag: trunk
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Turn your WordPress website into an Android and iOS mobile app. No coding required. Free preview and lifetime license.

== Description ==

WPMobile.App turns your WordPress website into an Android and iOS mobile app that you can publish on Google Play and the Apple App Store.

Customize your app from your WordPress dashboard, preview it on your phone for free, and purchase a lifetime license when you are ready to publish.

Your app uses your existing website content, with your own branding and unlimited push notifications. No coding required.

[Try your app for free](https://wpmobile.app/en/test-my-app/)

= Your WordPress website, as a mobile app =

Keep managing your content in WordPress. Changes to your website content are reflected in the app, without having to publish a new app version for every new post or page.

WPMobile.App uses a mobile-optimized WebView to display your website, with app features such as push notifications and a custom app icon.

= Customize your app from WordPress =

Set your app name, icon, colors and navigation from your WordPress dashboard.

Your published app carries your own branding, with no WPMobile.App branding or advertising added by me.

= Unlimited push notifications =

Send notifications to bring users back to your app when you publish content, share an announcement or launch a promotion.

* Send push notifications manually.
* Automatically notify users about new posts.
* Use your Firebase and Apple accounts for notification delivery.
* No per-notification fees charged by WPMobile.App.

= App usage statistics =

View app usage statistics directly in WordPress, including installations, popular pages and device types. Statistics are hosted on your website.

= Test before you buy =

Install the plugin and use the free WPMobile.App demo app to preview your website on your phone.

Check your design, navigation and key pages before purchasing a license.

[Preview your mobile app](https://wpmobile.app/en/test-my-app/)

= One-time payment, lifetime license =

The WordPress plugin is free to install. A paid WPMobile.App license is required to generate your own app for publication.

* Android: EUR 129.
* iOS: EUR 129.
* Android + iOS: EUR 239.

Prices exclude VAT. Each option is a lifetime license with a one-time payment and no WPMobile.App subscription.

Apple and Google developer accounts are required for store publication. Their registration or membership fees are separate from the WPMobile.App license.

= Guided publication =

Generate your app build from WPMobile.App, then follow the step-by-step instructions to submit it using your own Google Play or Apple developer account.

You do not need to install Android Studio or Xcode to generate your build. Store approval remains subject to Apple and Google's review requirements.

= Direct support from the developer =

Need help configuring your app or preparing it for publication? Get support directly from Amauri, the developer of WPMobile.App.

[Documentation and support](https://wpmobile.app/en/help/)

== Installation ==

1. In your WordPress dashboard, go to Plugins > Add New Plugin.
2. Search for WPMobile.App.
3. Install and activate the plugin.
4. Open the WPMobile.App settings.
5. Customize your app and preview it using the free demo app.
6. When you are ready to publish, purchase a license and follow the publication instructions.

You can also upload the wpappninja folder to /wp-content/plugins/ and activate the plugin from the Plugins screen.

== Frequently Asked Questions ==

= Is WPMobile.App free? =

The WordPress plugin is free to install, and you can preview your app using the free WPMobile.App demo app.

A paid license is required to generate your own Android or iOS app for publication.

= How much does it cost? =

A lifetime license costs EUR 129 for Android, EUR 129 for iOS, or EUR 239 for both platforms, excluding VAT.

There is no WPMobile.App subscription. Apple and Google developer account fees are separate.

= Can I test my app before buying? =

Yes. Install the plugin, configure your app and open your website in the WPMobile.App demo app on your phone.

This lets you check the result before purchasing a license.

[Get the demo app](https://wpmobile.app/en/test-my-app/)

= Do I need coding skills? =

No. You configure your app from your WordPress dashboard and follow the instructions to generate and publish it.

You do not need to use Android Studio or Xcode to generate your app build.

= Is this a native app or a WebView app? =

WPMobile.App creates an app that displays your WordPress website through a mobile-optimized WebView.

Users can install it from Google Play or the Apple App Store. It includes app features such as push notifications, a custom icon and your own branding.

= Does it work with WooCommerce? =

WPMobile.App supports WooCommerce websites. Use the free demo app to check your product pages, cart and checkout with your theme, extensions and payment methods before purchasing.

= Will my website content stay synchronized? =

Yes. The app uses your WordPress website content, so you continue managing your posts, pages and products in WordPress.

Content changes do not require a new store submission. Changes to the app itself may require generating and submitting an updated build.

= Can I send push notifications? =

Yes. WPMobile.App supports manual push notifications and automatic notifications for new posts.

Notifications use your Firebase and Apple accounts, with no per-notification fees charged by WPMobile.App.

= Do I need my own Apple and Google developer accounts? =

Yes. To publish on Google Play, you need a Google Play developer account. To publish on the Apple App Store, you need an Apple developer account.

The accounts belong to you, and their fees are paid separately to Google and Apple.

= Is publication on the stores guaranteed? =

No. WPMobile.App provides the app build and publication instructions, but Apple and Google review submissions independently.

Your app and its content must meet the requirements of each store.

= Will my app display WPMobile.App branding? =

No. Your published app uses your name, icon and branding. WPMobile.App does not add its own branding or advertisements to it.

= Where can I get help? =

See the [documentation and support resources](https://wpmobile.app/en/help/) for setup instructions and help from the developer.

= How can I report security bugs? =

You can report security bugs through the Patchstack Vulnerability Disclosure Program. The Patchstack team helps validate, triage, and handle security vulnerabilities.

[Report a security vulnerability](https://patchstack.com/database/vdp/wpappninja)

== Screenshots ==

1. Generate and update your Android and iOS app builds from your WPMobile.App account.
2. Track Android and iOS installations, app activity, popular content and user languages.
3. Compose push notifications with images and links, and choose your target audience.
4. Manage your mobile app settings, branding and navigation from your WordPress dashboard.

== Changelog ==

= 11.90 =
* Update .min file

= 11.89 =
* Harden the XSS fix

= 11.88 =
* Fix Cross Site Scripting (XSS). Thanks Patchstack and AndrewN

= 11.87 =
* Security: Broken Access Control (be sure the user have the right to see a notification) Thanks @patchstack @Peter Tang
* Security: Do not send as push the "retrieve pass by mail" from wpmobile

= 11.86 =
* Reenable mail to push
* Fix push to role
* Update FCM

= 11.85 =
* Security: Unauthenticated Stored Cross-Site Scripting

= 11.84 =
* Security: Harden how mail to push is triggered

= 11.83 =
* Security: Temporary disable mail to push, need a proper fix

= 11.82 =
* Security: Fix a Sensitive Data Exposure. Thanks Patchstack and Peter Tang

= 11.81 =
* Update Readme

= 11.80 =
* Bump versions

= 11.79 =
* Fix the url to register for notifications

= 11.78 =
* Fix Broken Access Control

= 11.77 =
* Fix a database error on duplicate entry

= 11.76 =
* Update DE locale
* Fix some download links
* Bump to WP v7.0

= 11.75 =
* Add Fluent Community push notifications

= 11.74 =
* Add an option to select categories for the auto push feature

= 11.73 =
* Change the default theme
* Fix a redirect issue after login
* Fix a sort issue on some apps

= 11.72 =
* Fix XSS on the login form

= 11.71 =
* Fix debug mode

= 11.70 =
* Switch from file_get_contents to wp_remote_get

= 11.69 =
* Add more debug info

= 11.68 =
* Add a debug feature for push

= 11.67 =
* Update French translations

= 11.66 =
* Add esperanto locale

= 11.65 =
* Bump supported version

= 11.64 =
* Fix chart not displayed on stats

= 11.63 =
* Add the date on the push schedule

= 11.62 =
* Remove the "rate me" banner
* Fix typo
* Update it translation

= 11.61 =
* Fix Peepso notifications

= 11.60 =
* Fix Peepso notifications
* Rating notice only for admins

= 11.59 =
* Fix rating link

= 11.58 =
* Add more Peepso notifications (messages and friends)
* Fix statistics about installations and login/register
* Fix the new notification form not displaying
* Add a "rate me" message

= 11.57 =
* Security: fix Open Redirect (thanks to Krzysztof Zając and Wordfence)

= 11.56 =
* Bump versions

= 11.55 =
* Fix a woocommerce description issue 

= 11.54 =
* Fix a touchstart issue with native theme

= 11.53 =
* Security: fix Unauthenticated Arbitrary Shortcode Execution (thanks Arkadiusz Hydzik and Wordfence)

= 11.52 =
* Fix how translations are loaded

= 11.51 =
* Fix Cross Site Scripting (XSS). Thanks to Le Ngoc Anh and Patchstack

= 11.50 =
* Update some links

= 11.49 =
* Fix CSRF issue. Thanks to Muhammad Daffa and Patchstack

= 11.48 =
* Fix XSS issue. Thanks to Muhammad Daffa and Patchstack
* Include Copy Carbon recipients on the mail push

= 11.47 =
* Fix the link to get the account service file

= 11.46 =
* More informations about the Android push configuration

= 11.45 =
* Fix a fatal error on push configuration page

= 11.44 =
* New push system for Android

= 11.43 =
* Suppress a php warning

= 11.42 =
* Better detection of the app with user agent
* Fix an XSS security issue (thanks CatFather and https://patchstack.com/)
* Add flag for zh locale

= 11.41 =
* Allow debug with the get parameter ?wpmobile_debug=true

= 11.40 =
* Fix a bug on some pagination system
* Fix a bug on some shortcode like content being removed
* Fix a bug on hashtag management
* Fix a bug on Peepso wishlist links

= 11.39 =
* Fix the right to see the preview page for non admin
* Add an option to disable the hashtag management
* Only enable hashtag management for Native interface theme
* Fix stats non populating properly
* Fix a division by 0
* Add support of automatorwp

= 11.38 =
* Fix the theme manager for WordPress 6.4

= 11.37 =
* Fix a bug on the push locales
* Fix a bug on the preview for role different than admin

= 11.36 =
* Update AR locale
* Better link detection for mail to push
* Include BCC recipient to mail to push

= 11.35 =
* Add a link to the push if there is one on the mail content
* Add 4 filters for push content `wpmobile_push_url` `wpmobile_push_title` `wpmobile_push_text` `wpmobile_push_image`

= 11.34 =
* Fix a bug on subscribe link on bbpress forum

= 11.33 =
* Fix PHP warning

= 11.32 =
* Fix a Woocommerce issue on tab opening

= 11.31 =
* Fix a Woocommerce issue on tab opening

= 11.30 =
* Fix a Woocommerce issue

= 11.29 =
* Fix the woocommerce product image

= 11.28 =
* Fix the avatar on Buddyboss notifications

= 11.27 =
* Add avatar for buddypress push
* Fix infinite scroll on buddyboss theme

= 11.26 =
* Fix a bug on Better Messages avatars
* Fix a bug on some peepso menus

= 11.25 =
* Fix some bugs for modified links by wpmobile

= 11.24 =
* Fix some bugs for BuddyBoss

= 11.23 =
* Fix a bug on the link management for Better Messages

= 11.22 =
* Fix a bug on the Name and logo page

= 11.21 =
* Fix an XSS security issue (thanks Juampa Rodríguez and https://patchstack.com/)
* Fix hashtag management for Better Messages

= 11.20 =
* Dont send Better Messages push if the user is online

= 11.19 =
* Fix an XSS security issue (thanks Rio Darmawan and https://patchstack.com/)

= 11.18 =
* Fix a bug with links on Better Messages
* Fix a bug where pagination is not visible

= 11.17 =
* Add an option to stop Better Messages push
* Fix a bug where Better Messages push can be sent to everyone

= 11.16 =
* Fix double push sent

= 11.15 =
* Do not send a push to the sender (better messages)

= 11.14 =
* Add push for Better Messages
* Fix an XSS security issue (CVE-2023-22702)

= 11.13 =
* Translate the banner in Bulgarian

= 11.12 =
* Fix a bug with Peepso
* Load the icons for all themes

= 11.11 =
* Remove wpmobile CSS if the native theme is not used
* Improve the performance of the Notifications tab

= 11.10 =
* Add an option to disable stats

= 11.9 =
* Add an option to send a push to a specific role

= 11.8 =
* Fix a bug with some Peepso links
* Fix a scroll issue on WooCommerce product pages
* Force the refresh of the licence status

= 11.7 =
* Update how the Gravity Forms push are sent
* Peepso name instead of username on push

= 11.6 =
* Allow to change the status bar color for every theme
* Fix a null value
* Fix a bug with infinite scroll and Peepso

= 11.5.1 =
* Minor fixes

= 11.5 =
* Minor fixes

= 11.4 =
* Fix a bug on iOS scroll
* Fix a bug on Gravity forms notifications
* Fix a bug on Lazy load images

= 11.3 =
* Fix a bug on Android toolbar

= 11.2 =
* Made the fix automatic

= 11.1 =
* Better fix for ios status bar

= 11.0 =
* Warning Big change on how the status bar is handled on the iOS app
** If you see a problem on the layout of your app:
** * Enable the option from the wpmobile plugin to allow old status bar support
** * Update the app from the wpmobile plugin to get the new version
** * Disable the old status bar support when app is approved
* Fix the default cache level
* Fix the ios notification when title+text
* Fix gravity form notifications
* Fix links with hashtag
* Fix unclear alert when unread push
* Fix double tap needed on dialog form
* Fix positionning of alert on ios
* Fix title bar color and size